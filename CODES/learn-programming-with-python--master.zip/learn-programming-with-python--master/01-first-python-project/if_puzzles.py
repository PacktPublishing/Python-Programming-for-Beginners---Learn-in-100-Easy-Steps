number = 5
if number < 0:
  number = number + 10
  number = number + 5
print(number)

# m = 15
#
# if m>20:
#   if m<20:
#     print("m>20")
#   else:
#     print("Who am I?")

# l = 15
#
# if (l < 20):
#   print("l<20")
#
# if (l > 20):
#   print("l>20")
# else:
#   print("Who am I?")



# k = 15
# if (k > 20):
# print(1)
# elif (k > 10):
# print(2)
# elif (k < 20):
# print(3)
# else:
# print(4)