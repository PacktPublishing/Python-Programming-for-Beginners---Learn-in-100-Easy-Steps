def calculate_simple_interest(principal, interest, duration) :
    return principal * (1 + interest * 0.01 * duration)

print(calculate_simple_interest(10000,5,5))
