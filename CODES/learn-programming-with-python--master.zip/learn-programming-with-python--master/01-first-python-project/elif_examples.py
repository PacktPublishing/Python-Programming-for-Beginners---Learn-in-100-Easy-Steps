i = 2
if i==1:
    print("i is 1")
elif i==2:
    print("i is 2")
elif i == 3:
    print("i is 3")
else:
    print("i is not 1 or 2 or 3")