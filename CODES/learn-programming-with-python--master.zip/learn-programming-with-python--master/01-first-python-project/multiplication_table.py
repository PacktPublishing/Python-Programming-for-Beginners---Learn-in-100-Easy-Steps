def print_multiplication_table(table, start, end):
    for i in range(start, end + 1):
        print(f"{table} * {i} = {table * i}")

# print multiplication table 5
print_multiplication_table(5, 1, 10)

# TODO : Make sure I learn about if
