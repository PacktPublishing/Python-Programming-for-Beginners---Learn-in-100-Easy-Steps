print("Hello World")

# TODO : Make sure I learn about for in depth