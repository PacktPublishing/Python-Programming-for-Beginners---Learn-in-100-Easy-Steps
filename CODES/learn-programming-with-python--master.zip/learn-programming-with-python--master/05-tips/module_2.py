import module_1

module_1.method_1()
module_1.ClassA().class_method_1()